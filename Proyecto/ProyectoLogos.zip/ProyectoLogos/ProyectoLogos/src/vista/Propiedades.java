package vista;

public class Propiedades {

    public static final int PANEL_DE_DIBUJO_ANCHO = 710;
    public static final int PANEL_DE_DIBUJO_LARGO = 650;
    
}
