
package logos;

import vista.VentanaPrincipal;

public class Logos {

     public static void main(String args[]){
        new VentanaPrincipal();
    }
    
}
